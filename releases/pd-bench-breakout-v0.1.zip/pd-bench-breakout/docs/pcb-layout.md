# PCB layout guidance

The supplied board is an **unrouted 80 x 70 mm placement starter**, not a finished layout. Its footprint nets match the schematic. There are no tracks, vias, ground pours or released manufacturing files.

## Stackup and rules

Use standard two-layer 1.6 mm FR-4 with 1 oz finished copper as the initial assumption. Route components and power mainly on the top; preserve an almost continuous ground plane on the bottom. Revisit 2 oz copper only if measured thermal results or the final geometry justify it.

| Feature | Starting value | Release action |
|---|---|---|
| Ordinary signal trace | 0.25 mm | Check vendor minimum |
| Main VBUS / VOUT path | 2 mm minimum where possible; broad pours preferred | Calculate neck and via limits; verify thermally |
| Ordinary clearance | 0.20 mm | Review with fabricator |
| Power net clearance | 0.50 mm outside package fanout | Use documented local fanout constraints where needed |
| Signal via | 0.60 mm pad / 0.30 mm drill | Confirm finished drill and annular ring |
| Power layer change | Prefer none; otherwise multiple 0.8/0.4 mm vias | Calculate and inspect actual current distribution |
| Copper to board edge | 0.50 mm | Include connector and hole clearances |
| Silkscreen | At least 0.8 mm text, 0.15 mm stroke | Read at 1:1 and check solder mask clipping |
| Mounts | 3.2 mm NPTH, M3 | Keep copper clear of screw heads and washers |

These are project choices, not a certification or universal current-carrying rule. The local project contains net classes; confirm they remain assigned after opening and saving in the installed KiCad version. Manufacturer land patterns can require smaller local spacing than the general routing rules.

## Placement priorities

1. Keep J1 at the left edge with its cable opening facing outward. Confirm its body, stakes, locating holes, mating datum and connector overhang against the GCT drawing. Ensure the edge does not interfere with the cable shell.
2. Shorten J1-to-F1-to-U2 in the final layout. U2 needs a very small return loop to ground; it should intercept the protected bus before that bus travels to the controller. The broad placement starter is not the final ESD-optimized position.
3. Put C2 directly beside U1 VIN and exposed GND pad; move it closer than its presentation spacing in the starter. Route CC lines directly over uninterrupted ground, away from the power neck and gate switching nodes. They are not a USB differential data pair and do not need USB data-pair length matching.
4. Route fused power through Q1 to J2 without long narrow necks. Q1's large tab is **VOUT**, not ground. Give it copper area while keeping the bus return intact below.
5. Keep R3, R4 and D1 close to Q1 gate/source. Place R2 and the voltage-setting resistors close to U1 where practical; keep VSET away from fast edges.
6. Keep J3/J4, indicators and probe pads reachable with the cable and terminal wires fitted. Label output polarity on both sides and place the selector warning next to J3.

## Manufacturing checks

Review every land pattern against the exact orderable part. Pay particular attention to U1's 1.8 x 2.5 mm exposed pad, U2's grounded pad, Q1's tab, and the USB locator-hole spacing. The generic header holes are 1.0 mm while the selected Wurth drawings recommend nominal 1.1 mm: reconcile pin tolerance, finished plating and pad annular ring before release.

Use a stencil and controlled reflow for DFN/WSON parts. Split thermal-pad paste apertures if advised by the assembler. Avoid open vias in paste areas unless the fabrication process supports them. Add thermal stitching vias adjacent to the pad where appropriate. Through-hole terminal and headers can be hand soldered after reflow.

Finish routing, refill zones, inspect both return paths, and run DRC with schematic parity. Resolve the reported USB locating-hole clearance against the connector drawing and fabricator capability. Do not hide it with a blanket rule exemption. Review mask slivers, paste coverage, fiducials, tooling and panelization with the intended assembler. Only then generate and independently inspect Gerbers, drills and assembly drawings.
