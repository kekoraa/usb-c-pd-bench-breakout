# KiCad project

Open **pd-bench.kicad_pro** in KiCad 10.0.x. Files were parsed/exported using KiCad CLI 10.0.5. Earlier KiCad versions have not been checked. Keep this folder and its local libraries together.

```text
hardware/
  pd-bench.kicad_pro       Project settings and net classes
  pd-bench.kicad_sch       One-sheet A3 schematic
  pd-bench.kicad_pcb       Unrouted placement starter
  sym-lib-table           Project-relative symbol library
  fp-lib-table            Project-relative footprint library
  libraries/
    PD_Bench.kicad_sym
    PD_Bench.pretty/
```

The PCB contains 27 schematic-linked footprints plus four board-only mounting holes. It has no routing. A ratsnest is expected. Do not export it for fabrication.

Local symbols and footprints are snapshots derived from KiCad's installed standard libraries. The MOSFET symbol was adapted to the selected DMP4015SK3, retaining G1/D2/S3 pin mapping. Check the package and polarity in the manufacturer drawing before release. Optional 3D bodies refer to KiCad's standard model library and may require the matching installed library; the electrical design does not depend on those models.

To continue: inspect the schematic, update PCB from schematic, review footprint associations and all pad numbers, resolve the documented package-rule issues, optimize placement, route power and CC, fill ground zones, then run DRC with schematic parity. Footprint locations are provisional, especially the clamp and U1 decoupling distances. Refer to the layout guide rather than copying the placement spacing as a routing specification.

Re-run checks from the repository root, with `kicad-cli` available:

```sh
kicad-cli sch erc -o verification/erc.rpt hardware/pd-bench.kicad_sch
kicad-cli sch export netlist --format kicadxml -o verification/netlist.xml hardware/pd-bench.kicad_sch
kicad-cli pcb drc --schematic-parity -o verification/drc.rpt hardware/pd-bench.kicad_pcb
python verification/check_connectivity.py
```

The last check compares exported schematic pin nets with the recorded design map. It is not an electrical simulator. After intentional design changes, update the map as part of review rather than changing it merely to make the check pass.
