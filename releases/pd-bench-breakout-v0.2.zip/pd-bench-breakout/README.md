# PD Bench
### USB-C Power Delivery trigger / breakout

**Revision 0.2 | Design-stage, unbuilt prototype | September 2026**

PD Bench is a firmware-free USB-C PD sink design that exposes a charger's negotiated DC rail through a screw terminal. It explores power negotiation, component derating, protection coordination, manufacturable footprints, and practical test planning in a small two-layer PCB.

![Routed PCB copper layout](docs/images/pcb-routed-front.svg)

*Revision 0.2 routed CAD layout; unbuilt and physically unvalidated.*

![Power and control architecture](docs/images/block-diagram.svg)

The board targets **5, 9, 12, 15, or 20 V requests and a 2 A continuous output**, up to 40 W at 20 V. These are design targets, not measured ratings. It does not convert voltage locally: the USB-C source supplies the negotiated rail. It has no adjustable constant-current mode and is not a replacement for a protected laboratory power supply.

## Project status

| Item | Status |
|---|---|
| Architecture, calculations, BOM, schematic | Draft design completed |
| Native KiCad schematic | Included; electrical rules report supplied |
| Native PCB | 80 x 70 mm, **fully routed**; 112 track segments, 48 vias, 3 filled copper zones |
| Physical assembly, PD interoperability, thermal and protection tests | **Not performed** |
| Manufacturing files | Not released; no Gerbers or drill files supplied |

Read [verification status](verification/README.md) for the actual checks and remaining issues. The USB footprint uses a documented 0.19 mm internal hole-clearance rule matching its nominal land pattern; fabricator acceptance remains open. A clean schematic ERC does not establish electrical performance, protection effectiveness, or manufacturing readiness.

## Design features

- Hynetek **HUSB238_002DD** autonomous sink; no MCU or firmware.
- One-shunt voltage selection and a separate output-enable shunt, default off.
- 3 A one-time fuse, 22 V transient suppressor, and a 40 V P-channel output MOSFET with a gate clamp.
- Amber input and green output rail-presence LEDs.
- Two-position 5.00 mm screw terminal and accessible voltage/ground test pads.
- Local symbol and footprint snapshots for portable editing.

The controller and its variant selection follow the [Hynetek documentation](https://en.hynetek.com/2421.html). The VBUS clamp is based on [TI's TVS2200](https://www.ti.com/product/TVS2200). Detailed references and component decisions are in the [design report](docs/design-report.md).

## Voltage selection

| J3 shunt position | Request ceiling |
|---|---|
| Pins 1-2 | 5 V; default assembly position |
| Pins 3-4 | 9 V |
| Pins 5-6 | 12 V |
| Pins 7-8 | 15 V |
| Pins 9-10 | 20 V; electrically open parking position |

**A missing selector shunt also requests 20 V.** Fit exactly one selector shunt. Unplug USB before changing J3. Keep J4 open during selection and initial inspection.

12 V is not guaranteed. A charger must advertise a suitable fixed PDO; this design requests 2.25 A to leave overhead for a 2 A load. An advertised profile below 2.25 A can be skipped, and a lower voltage can result. LEDs do not confirm the contract or identify the actual voltage. Measure the output before attaching a load.

## Open in KiCad

1. Extract the complete repository folder.
2. Use KiCad **10.0.x** and open `hardware/pd-bench.kicad_pro`.
3. Open the schematic and PCB from the project manager. The local library tables use `${KIPRJMOD}`; keep the `hardware/libraries` folder together with the project.
4. Follow [KiCad workflow](hardware/README.md) and [layout guidance](docs/pcb-layout.md) for routing decisions and pre-fabrication review. No import conversion is necessary.

## Documentation

- [Specification](docs/specification.md) and [block diagram](docs/images/block-diagram.svg)
- [Schematic plan and pin connections](docs/schematic-plan.md); [schematic drawing](docs/images/pd-bench.svg)
- [BOM](bom/bom.csv) and [component selection](docs/components.md)
- [Front copper](docs/images/pcb-routed-front.svg), [back copper](docs/images/pcb-routed-back.svg) and [layout guidance](docs/pcb-layout.md)
- [Design report and calculations](docs/design-report.md), [routing review](docs/routing-review.md), and [bare-board CAD render](docs/images/pcb-bare-board.png)
- [Future bring-up plan](docs/validation-plan.md) and [blank test log](docs/test-log.csv)
- [Portfolio statements and interview notes](docs/portfolio-notes.md)
- [Sources](docs/references.md), [open issues](docs/open-issues.md), and [third-party notices](THIRD_PARTY_NOTICES.md)

## Intended use boundary

Future evaluation is limited to passive DC loads and suitable USB-C PD sources. There is no reverse-current blocking, battery charging, USB data path, PPS/EPR support, galvanic isolation, or precision current limiting. Do not connect another supply or a battery to the output. External inductive loads require their own suppression. This revision does not establish system-level ESD immunity or USB-IF certification.

## Repository use

Upload the contents of this folder as a repository, retain the design-stage status, and publish the actual check reports with it. The current PCB is routed and passes the documented project DRC; that does not establish hardware performance or fabrication approval. Review [licensing notes](LICENSE-NOTES.md) before choosing a license for original project files. Manufacturer datasheets are linked rather than redistributed.
