# Third-party notices

The local symbol library and footprints in `hardware/libraries` derive from the KiCad project libraries distributed with KiCad 10.0.5. Credit: KiCad library contributors. The original symbol names and footprint filenames are recorded in `verification/design-connectivity.json`.

Upstream sources: [KiCad symbols](https://gitlab.com/kicad/libraries/kicad-symbols) and [KiCad footprints](https://gitlab.com/kicad/libraries/kicad-footprints). These libraries use **Creative Commons Attribution-ShareAlike 4.0 International**, with the KiCad library exception for designs using the libraries. See the [library license and exception](https://www.kicad.org/libraries/license/) and [CC BY-SA 4.0 legal terms](https://creativecommons.org/licenses/by-sa/4.0/legalcode).

Changes: symbols were flattened into a project-local library, identifiers and selected values/footprint fields changed, and the IRF4905 drawing adapted as the DMP4015SK3 symbol with its matching G1/D2/S3 mapping and selected-device description. Footprint geometry was copied without claiming manufacturer approval. Local library snapshots and their adaptations retain the upstream library license. This notice does not impose the library license on original design documents where the exception applies.

Manufacturer names and part numbers identify engineering references and do not imply endorsement. No manufacturer datasheets or component certification marks are included as project certification.

Revision 0.2 modifications: local J3/J4 header footprints use 1.1 mm nominal drill in place of the generic 1.0 mm drill, following the selected Wurth parts. USB footprint copper and locator geometry are retained; its special design rule is documented separately.
