# Licensing notes

No public reuse license has been selected for the original project documents and design files. The repository owner should choose one before advertising the project as open hardware. Public visibility on GitHub does not itself grant a general reuse license.

The KiCad-derived library material retains its upstream license and attribution described in THIRD_PARTY_NOTICES.md. Those terms are separate from the owner's choice for original project content. Manufacturer datasheets, trademarks and part drawings retain their respective owners' rights and are linked as references.
